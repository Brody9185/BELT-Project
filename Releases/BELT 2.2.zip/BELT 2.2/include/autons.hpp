#include "main.h"

//functions

void allPIDWait();
extern void defaultConstants();
void testAuton();

//From v1
void ang_PID();
void lin_PID();
void left_side();
void right_side();
void skills_auto();
void do_nothing();
void pos_example();
void point_example();

//PID
extern ez::PID linPID;

extern ez::PID angPID; 
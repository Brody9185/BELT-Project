#include "lemlib/chassis/trackingWheel.hpp"
#include "main.h"
#include "pros/abstract_motor.hpp"
#include "pros/motors.h"
#include "lemlib/api.hpp"
#include "pros/rotation.hpp"


// drive rpm
int driveRPM = 600;
std::vector<int8_t> lemLeftMotors = {1,2,3,4};
std::vector<int8_t> lemRightMotors = {5,6,7,8};
pros::motor_brake_mode_e_t driver_preference_brake = pros::E_MOTOR_BRAKE_COAST;
int imuPort = 7;
pros::Rotation VerTracking(8);
pros::Rotation HorTracking(9);

void initDrive(){

}

std::vector<int> ezLeftMotors = {lemLeftMotors[0],lemLeftMotors[1],lemLeftMotors[2],lemLeftMotors[3]};
std::vector<int> ezRightMotors = {lemRightMotors[0],lemRightMotors[1],lemRightMotors[2],lemRightMotors[3]};


ez::Drive chassis(
    // These are your drive motors, the first motor is used for sensing!
    ezLeftMotors,     // Left Chassis Ports (negative port will reverse it!)
    ezRightMotors,  // Right Chassis Ports (negative port will reverse it!)

    imuPort,      // IMU Port
    lemlib::Omniwheel::NEW_275,  // Wheel Diameter (Remember, 4" wheels without screw holes are actually 4.125!)
    driveRPM);   // Wheel RPM


//LEMLIB ODOM
pros::Imu imu (imuPort);
pros::MotorGroup left_motors(lemLeftMotors,pros::MotorGearset::blue); // left motors on ports 1, 2, 3
pros::MotorGroup right_motors(lemRightMotors,pros::MotorGearset::blue); // right motors on ports 4, 5, 6

// drivetrain settings
lemlib::Drivetrain drivetrain(&left_motors, // left motor group
                              &right_motors, // right motor group
                              10, // 10 inch track width
                              lemlib::Omniwheel::NEW_275, // using new 4" omnis
                              driveRPM, // drivetrain rpm is 360
                              2 // horizontal drift is 2 (for now)
);

// vertical tracking wheel
lemlib::TrackingWheel vertical_tracking_wheel(&VerTracking, lemlib::Omniwheel::NEW_275_HALF, -5.75,1);
// horizontal tracking wheel
lemlib::TrackingWheel horizontal_tracking_wheel(&HorTracking, lemlib::Omniwheel::NEW_275_HALF, -5.75,1);

lemlib::OdomSensors sensors(&vertical_tracking_wheel, // vertical tracking wheel 1, set to null
                            nullptr, // vertical tracking wheel 2, set to nullptr as we are using IMEs
                            &horizontal_tracking_wheel, // horizontal tracking wheel 1
                            nullptr, // horizontal tracking wheel 2, set to nullptr as we don't have a second one
                            &imu // inertial sensor
);

// lateral PID controller
lemlib::ControllerSettings lateral_controller(10, // proportional gain (kP)
                                              0, // integral gain (kI)
                                              3, // derivative gain (kD)
                                              3, // anti windup
                                              1, // small error range, in inches
                                              100, // small error range timeout, in milliseconds
                                              3, // large error range, in inches
                                              500, // large error range timeout, in milliseconds
                                              20 // maximum acceleration (slew)
);

// angular PID controller
lemlib::ControllerSettings angular_controller(2, // proportional gain (kP)
                                              0, // integral gain (kI)
                                              10, // derivative gain (kD)
                                              3, // anti windup
                                              1, // small error range, in degrees
                                              100, // small error range timeout, in milliseconds
                                              3, // large error range, in degrees
                                              500, // large error range timeout, in milliseconds
                                              0 // maximum acceleration (slew)
);

// create the chassis
lemlib::Chassis odomChassis(drivetrain, // drivetrain settings
                        lateral_controller, // lateral PID settings
                        angular_controller, // angular PID settings
                        sensors // odometry sensors
);
#include "main.h"
#include "EZ-Template/util.hpp"

void setIntake(int intakePower){
    intakeM.move(intakePower);
}

void pistonToggle(){
    if(!Piston1.get()){
        Piston1.set(true);
    }
    else if(Piston1.get()){
        Piston1.set(false);
    }
}

// arm pid
ez::PID armPID{1,1,1,1,"arm"};


#include "main.h"
#include "pros/motors.h"

pros::Motor intakeM (10, pros::v5::MotorGears::green, pros::v5::MotorUnits::rotations);
pros::Motor armM (11, pros::v5::MotorGears::green, pros::v5::MotorUnits::rotations);

ez::Piston Piston1('A',false);

pros::adi::DigitalIn increase('G'); //limit swith for auton selector
pros::adi::DigitalIn decrease('H'); //limit swith for auton selector

int countC = 0;//counter for controller display
bool armUp = false;//if arm up
#include "EZ-Template/piston.hpp"
#include "main.h"
#include "pros/adi.h"
#include "pros/adi.hpp"

extern pros::Motor intakeM;
extern pros::Motor armM;

extern ez::Piston Piston1;

extern pros::adi::DigitalIn increase; //limit swith for auton selector
extern pros::adi::DigitalIn decrease; //limit swith for auton selector

extern int countC;//counter for controller display
extern bool armUp;//if arm up
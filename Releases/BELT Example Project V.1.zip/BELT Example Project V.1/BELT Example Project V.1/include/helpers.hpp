#include "main.h"

void setIntake(int intakePower);

void pistonToggle();

extern ez::PID armPID;
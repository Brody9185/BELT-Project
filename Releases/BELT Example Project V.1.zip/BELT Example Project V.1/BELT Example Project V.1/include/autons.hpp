#pragma once

#include "EZ-Template/drive/drive.hpp"

void default_constants();


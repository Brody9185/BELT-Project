#include "main.h"
#include "EZ-Template/drive/drive.hpp"

extern Drive chassis;

extern pros::motor_brake_mode_e_t driver_preference_brake;

void initDrive(); // initilize chassis settings

//LEMLIB ODOM
extern pros::MotorGroup left_motors; // left motors on ports 1, 2, 3
extern pros::MotorGroup right_motors; // right motors on ports 4, 5, 6
#include "main.h"

//functions

void allPIDWait();
void defaultConstants();
void testAuton();

//From v1
void ang_PID();
void lat_PID();
void left_side();
void right_side();
void skills_auto();
void do_nothing();
void pos_example();
void point_example();